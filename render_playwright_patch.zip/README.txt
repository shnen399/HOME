使用說明（先裝瀏覽器版本）
=================================

本壓縮包只處理兩件事：
1) 設定 Node 版本：`.node-version` -> 18.20.3
2) 在建置時自動安裝 Playwright 的 Chromium 瀏覽器（含系統依賴）

包含檔案：
- .node-version
- render-build.sh

如何使用：
1. 下載並解壓縮此 ZIP。
2. 把 `.node-version` 與 `render-build.sh` 放到你專案的根目錄（與 requirements.txt / package.json 同層）。
3. 在 Render 服務頁 → 點 **Manual Deploy** 前先按 **Clear build cache & deploy**（清除快取並重新部署）。
4. 觀察 Build Log 中應出現：
   - 使用 Node v18.20.3
   - 執行 `npx playwright install chromium --with-deps` 成功訊息
5. 若你需要安裝全部瀏覽器，將 `render-build.sh` 內的 `chromium` 改為空白（或 `chromium firefox webkit`）：
   npx --yes playwright@1.46.0 install --with-deps
   或
   npx --yes playwright@1.46.0 install chromium firefox webkit --with-deps

注意：
- 將此檔加入版本庫後，Render 的 Build Command 保持 `bash render-build.sh`（或在既有 build script 的最後呼叫）。
- 若你的專案已經有自己的 build.sh，請把上述安裝命令加到你的腳本最後，不要重複安裝。
