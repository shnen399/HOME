#!/usr/bin/env bash
set -euo pipefail

echo "==> Configure Playwright cache path"
export PLAYWRIGHT_BROWSERS_PATH=/opt/render/.cache/ms-playwright

echo "==> Install Playwright Chromium browser (with system deps)"
# Pin to a recent stable Playwright to avoid breaking changes; adjust if you already pin in package.json
npx --yes playwright@1.46.0 install chromium --with-deps

echo "==> Done installing Playwright browsers"
